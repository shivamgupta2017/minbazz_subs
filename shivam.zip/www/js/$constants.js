angular.module('starter')
.constant('$constants', {
    appId: 'MINBAZAAR',
    appSecret: 'GhantaSecret',
    jsonApiUrl: "https://www.minbazaar.com/subs/admin/service/",
    restApiUrl: "https://www.minbazaar.com/server/partials"
                    
})
